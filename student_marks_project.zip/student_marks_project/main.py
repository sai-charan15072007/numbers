# main.py

from data import subjects
from calculator import calculate_total, calculate_percentage, calculate_grade
from display import display_result


# String
student_name = input("Enter student name: ")

# List
marks = []

print("\nEnter marks out of 100:")

for subject in subjects:
    mark = int(input("Enter marks for " + subject + ": "))
    marks.append(mark)


# Dictionary
student_marks = {}

for i in range(len(subjects)):
    student_marks[subjects[i]] = marks[i]


# Calculate result
total = calculate_total(marks)
percentage = calculate_percentage(total)
grade = calculate_grade(percentage)


# Tuple
result = (student_name, total, percentage, grade)


# Display result
display_result(
    result[0],
    student_marks,
    result[1],
    result[2],
    result[3]
)