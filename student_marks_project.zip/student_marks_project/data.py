# data.py

# List of subjects
subjects = ["English", "Maths", "Science", "Social", "Computer"]

# Set of possible grades
grades = {"A+", "A", "B", "C", "D", "F"}

# Tuple containing maximum marks
max_marks = (100, 100, 100, 100, 100)