# display.py

def display_result(name, student_marks, total, percentage, grade):
    print("\n==============================")
    print("       STUDENT RESULT")
    print("==============================")

    print("Name:", name)

    print("\nSubject Marks:")
    for subject, mark in student_marks.items():
        print(subject, ":", mark)

    print("\nTotal:", total, "/ 500")
    print("Percentage:", percentage, "%")
    print("Grade:", grade)

    print("==============================")