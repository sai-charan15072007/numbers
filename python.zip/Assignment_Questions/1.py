class Person:
    def __init__(self, name, pinno):
        self.name = name
        self.pinno = pinno

    def display_info(self):
        print("name: ", self.name)
        print("pinno: ", self.pinno)


class Student(Person):
    def display_info(self):
        print("Student name: ", self.name)
        print("Maximum pinno: ", self.pinno)


class Teacher(Person):
    def display_info(self):
        print("Teacher name: ", self.name)
        print("Maximum pinno: ", self.pinno)


c = Student("Vgn", 180)
b = Teacher("ABC", 150)
c.display_info()
b.display_info()
