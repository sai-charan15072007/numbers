class Shape:
    def __init__(self, Color, Area):
        self.Color = Color
        self.Area = Area

    def display_info(self):
        print("Color: ", self.Color)
        print("Area: ", self.Area)


class Circle(Shape):
    def display_info(self):
        print("Circle Color: ", self.Color)
        print("Area: ", self.Area)


class Rectangle(Shape):
    def display_info(self):
        print("Rectangle Color: ", self.Color)
        print("Area: ", self.Area)


c = Circle("Green", 180)
b = Rectangle("Red", 150)
c.display_info()
b.display_info()
