class Animal:
    def sound(self):
        print("Sounds of Animals")


class Dog(Animal):
    def sound(self):
        print("Dog always barks")


class Cat(Animal):
    def sound(self):
        print("Cat says meows")


class Cow(Animal):
    def sound(self):
        print("Cow sounds Moo")


dog = Dog()
cat = Cat()
Cow = Cow()

dog.sound()
cat.sound()
Cow.sound()