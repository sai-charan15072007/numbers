class Emp:
    def __init__(self, name, pinno):
        self.name = name
        self.pinno = pinno

    def display_info(self):
        print("Name: ", self.name)
        print("Pinno: ", self.pinno)


class Mgr(Emp):
    def display_info(self):
        print("Mgr Name: ", self.name)
        print("Pinno: ", self.pinno)


class Dev(Emp):
    def display_info(self):
        print("Dev Name: ", self.name)
        print("Pinno: ", self.pinno)


c = Mgr("Vgn", 180)
b = Dev("ABC", 150)
c.display_info()
b.display_info()
