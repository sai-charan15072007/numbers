from abc import ABC, abstractmethod


class Employee(ABC):

    @abstractmethod
    def calculate_salary(self):
        pass


class FullTimeEmp(Employee):
    def __init__(self, monthly_salary):
        self.monthly_salary = monthly_salary

    def calculate_salary(self):
        return self.monthly_salary


class PartTimeEmp(Employee):
    def __init__(self, hours_worked, hour_salary):
        self.hours_worked = hours_worked
        self.hour_salary = hour_salary

    def calculate_salary(self):
        return self.hours_worked * self.hour_salary


# Creating objects
fte = FullTimeEmp(50000)
pte = PartTimeEmp(80, 300)

# Display salaries
print("Full-Time Employee Salary:", fte.calculate_salary())
print("Part-Time Employee Salary:", pte.calculate_salary())
