from abc import ABC, abstractmethod


class Payment(ABC):
    @abstractmethod
    def pay(self):
        pass


class CreditCardPayment(Payment):
    def pay(self, amount):
        print("Amount paid via credit card is: ", amount)

class UPIPayment(Payment):
    def pay(self, amount):
        print("Amount paid via UPI is: ", amount)

class CashPayment(Payment):
    def pay(self, amount):
        print("Amount paid via cash is: ", amount)


ccp = CreditCardPayment()
upi = UPIPayment()
cash = CashPayment()

ccp.pay(1000)
upi.pay(2000)
cash.pay(3000)