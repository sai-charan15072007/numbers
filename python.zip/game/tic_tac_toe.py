atiX = str(input(f"Enter player 1 Name: \t"))
O = str(input(f"Enter player n2 Name: \t"))

def enter_game():
    print("\n 1. Introduce Game...")
    print("\n 2. Play Game")
    print("\n 3. Exit Game")
    choice = int(input("\n \n\n \t\t\tEnter the Choice: "))

    match choice:
        case 1:
            return introduce()
        case 2:
            return play_game()
        case 3:
            exit()



def introduce():
    print("Lorem Lorem")
    return enter_game()

def print_board(board):
    """Prints the current state of the game board."""
    print("\n")
    print(f" {board[0]} | {board[1]} | {board[2]} ")
    print("---|---|---")
    print(f" {board[3]} | {board[4]} | {board[5]} ")
    print("---|---|---")
    print(f" {board[6]} | {board[7]} | {board[8]} ")
    print("\n")

def check_win(board, player):
    """Checks if the specified player has won the game."""
    win_conditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Horizontal rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Vertical columns
        [0, 4, 8], [2, 4, 6]              # Diagonal lines
    ]
    return any(all(board[cell] == player for cell in combo) for combo in win_conditions)

def check_tie(board):
    """Checks if the board is completely full with no winner."""
    return all(space in [X, O] for space in board)

def play_game():
    """Main loop to orchestrate the Tic-Tac-Toe game."""
    # Initialize the board with position numbers 1-9
    board = [str(i) for i in range(1, 10)]
    current_player = 'X'
    
    print("Welcome to Tic-Tac-Toe!")
    print("Enter a number (1-9) to place your mark on the corresponding tile.")

    while True:
        print_board(board)
        
        # Safely handle player inputs
        try:
            choice = int(input(f"Player {current_player}'s turn. Choose a position (1-9): ")) - 1
            if choice < 0 or choice > 8 or board[choice] in [X, O]:
                print("Invalid move! That spot is either taken or out of bounds. Try again.")
                continue
        except ValueError:
            print("Invalid input! Please enter a valid number between 1 and 9.")
            continue

        # Execute move
        board[choice] = current_player

        # Check game status
        if check_win(board, current_player):
            print_board(board)
            print(f"Congratulations! Player {current_player} wins! 🎉")
            break
        elif check_tie(board):
            print_board(board)
            print("It's a tie! 🤝")
            break

        # Switch turns
        current_player = 'O' if current_player == 'X' else 'X'

if __name__ == "__main__":
    enter_game()



def get_user_role(role_code):
    match role_code:
        case "A":
            return "Admin"
        case "M":
            return "Moderator"
        case "U":
            return "User"
        case _:
            return "Guest"  # Default case

# print(get_user_role("A"))  # Output: Admin
# print(get_user_role("Z"))  # Output: Guest
