class Employee:
    def __init__(self, emp_id, salary):
        self.emp_id = emp_id
        self.emp_salary = salary

    def __eq__(self, other):
        return self.emp_salary == other.emp_salary

e1 = Employee(101, 50000)
e2 = Employee(102, 80000)
e3 = Employee(103, 50000)

print(e1 == e2)
print(e1 == e3)