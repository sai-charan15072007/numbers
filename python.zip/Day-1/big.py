def big(a, b):
    if a > b:
        return a
    else:
        return b


num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

result = big(num1,num2)

print("Bigger Number is: ", result)