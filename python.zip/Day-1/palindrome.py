def is_palindrome(text):
    # Convert to lowercase to make the check case-insensitive
    clean_text = str(text).lower()
    # Compare the string with its reverse
    if clean_text == clean_text[::-1]:
        print( text ,"is Palindrome")
    else:
        print("Not a Palindrome")



entered_text = input("Enter text: ")
is_palindrome(entered_text)