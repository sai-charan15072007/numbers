def reverse(text):
    reversed_text = "".join(reversed(text))
    return reversed_text

text = str(input("Enter the string: "))
reversed_text = reverse(text)
print(reversed_text)